# quiets concerns of R CMD check re: the .'s that appear in pipelines
if (getRversion() >= "2.15.1") {
  utils::globalVariables(c("spline_tot_FDR", "spline_tot_stat", "spline_tot_pval"))
}

#' Calculates FDR corrected p-values for the total, linear and non-linear associations in EWAS
#'
#' @param meth_data A matrix containing methylation data
#' @param expo_cov A data.frame containing all variables needed for regression (exposures and confounders)
#' @param exposures A character vector naming the exposures
#' @param confounders A character vector containing names of the confounders
#' @param technical_confounders A character vector defining technical confounders the regression will be adjusted to
#' @param maxit The number of iterations for each robust regression
#' @param knots A scalar defining the number of knots for the rcs function (see help for parms in the rms::rcs function). Default = 3. Only values between 3 and 5 are accepted
#' @param ncores The number of cores used for parallel computing, by default all available cores
#' @param path Path for saving the result file
#' @param file_name File name without extension
#'
#' @return A data.frame with different p-values for each CpG for each exposure: total, linear, non-linear and FDR corrected p-value for total (linear and non-linear associations)
#' @export
#' @import dplyr
#' @importFrom  here here
#' @import parallel
#' @importFrom stats p.adjust
#' @importFrom rlang .data
#' @importFrom doParallel registerDoParallel
#' @importFrom bigstatsr nb_cores
#' @importFrom foreach registerDoSEQ
#' @importFrom tibble rownames_to_column

NonLinearityCheck <- function(meth_data,
                              expo_cov,
                              exposures,
                              confounders,
                              technical_confounders,
                              maxit,
                              knots = 3,
                              ncores = bigstatsr::nb_cores(),
                              path,
                              file_name) {


  # The code was adapted from Johanna Lepeule (sent by email 18/06/2021)

  # Set the parallel computing conditions

  # Create a set of copies of R running in parallel and communicating over sockets
  cl <- parallel::makeCluster(getOption("cl.cores", ncores))
  parallel::clusterEvalQ(cl, library("magrittr"))

  # Register the parallel backend
  doParallel::registerDoParallel(cl)

  # Explicitly register a sequential parallel backend. This will prevent a warning message
  # from being issued if the %dopar% function is called and no parallel backend has been registered.
  foreach::registerDoSEQ()

  # Stop the cluster
  on.exit(parallel::stopCluster(cl))

  # 1. Run robust linear regressions for each CpG in function of exposure, adjusted for covariates

  # Create an object where regression results for all exposures will be stored

  res_all_expo <- data.frame()

  for (i in seq_along(exposures)) {

    cat("Progress:", i, "/", length(exposures), "exposures\n")
    cat("Exposure processed:", exposures[i], "\n")

    # Run robust linear regressions separately for each CpG and adjust p values for multiple testing
    nonlin_check <- parallel::parApply(
      cl = cl,
      X = meth_data,
      MARGIN = 2,
      FUN = .NonLinearity,
      exposure = exposures[i],
      expo_cov = expo_cov,
      confounders = confounders,
      technical_confounders = technical_confounders,
      maxit = maxit,
      knots = knots
    )

    # Transform results for an exposure into a data frame
    nonlin_check_df <- nonlin_check %>%
      simplify2array() %>%
      t() %>%
      as.data.frame() %>%
      dplyr::mutate(Exposure = exposures[i])

    names(nonlin_check_df) <- c("spline_tot_pval",
                                "spline_lin_pval",
                                "spline_nonl_pval",
                                "spline_tot_stat",
                                "Exposure")

    # Adjust p values
    nonlin_check_res <- nonlin_check_df %>%

      # spline_tot_FDR is the result of interest (FDR-corrected p-value for the non-linear association)
      dplyr::mutate(spline_tot_FDR = stats::p.adjust(.data$spline_tot_pval, method = "BH")) %>%
      tibble::rownames_to_column(var = "CpG") %>%
      dplyr::select(CpG:spline_tot_stat, spline_tot_FDR, Exposure)

    # Print results
    # Count CpGs with non-linear associations

    nonl_CpGs <- nonlin_check_res %>%
      dplyr::filter(spline_tot_FDR < 0.05) %>%
      dplyr::select(CpG)

    cat("No. of CpGs with non-linear associations:",
        nrow(nonl_CpGs),
        "\n")

    # Append the result list
    res_all_expo <- dplyr::bind_rows(res_all_expo, nonlin_check_res)
  }

  # Write results to a file
  saveRDS(res_all_expo, file = here::here(path, paste0(file_name, ".RDS")))

  return(res_all_expo)

}



#' Calculates FDR corrected p-values for the total, linear and non-linear associations in global DNA methylation study
#'
#' @param data A data.frame containing global methylation variable, exposure variables, confounders and technical confounders
#' @param global_meth A string defining global methylation name
#' @param exposures A character vector containing names of the exposures
#' @param confounders A list whose each element is a character vector defining names of confounders the regression will be adjsuted to
#' @param technical_confounders A character vector defining technical confounders the regression will be adjusted to
#' @param maxit The number of iterations for each robust regression
#'
#' @return A data.frame with different p-values for each CpG for each exposure: total, linear, non-linear and FDR corrected p-value for total (linear and non-linear associations)
#' @export
#' @import dplyr
#' @importFrom here here

NonLinearityCheckGlobalMeth <- function(data,
                                        global_meth,
                                        exposures,
                                        confounders = NULL,
                                        technical_confounders = NULL,
                                        maxit) {

  res_all_expo <- data.frame()

  for (i in seq_along(exposures)) {

    # Run robust linear regressions separately for each CpG and adjust p values for multiple testing
    nonlin_check <- .NonLinearityGlobalMeth(data = data,
                                           global_meth = global_meth,
                                           exposure = exposures[i],
                                           confounders = confounders,
                                           technical_confounders = technical_confounders,
                                           maxit = maxit)

    # Transform results for an exposure into a data frame
    nonlin_check_df <- nonlin_check %>%
      simplify2array() %>%
      t() %>%
      as.data.frame() %>%
      dplyr::mutate(Exposure = exposures[i])

    res_all_expo <- rbind(res_all_expo, nonlin_check_df)
  }

  names(res_all_expo) <- c("spline_tot_pval",
                           "spline_lin_pval",
                           "spline_nonl_pval",
                           "spline_tot_stat",
                           "Exposure")

  # Print results
  # Count non-linear associations

  nonl_assoc <- res_all_expo %>%
    dplyr::filter(spline_tot_pval < 0.05)

  cat("No. of associations with non-linear associations:",
      nrow(nonl_assoc),
      "\n")

  return(res_all_expo)

}


