testthat::test_that("Regression works", {

  library(here)
  library(magrittr)
  library(tidyselect)
  library(IlluminaHumanMethylation450kanno.ilmn12.hg19)

  test_meth <- readRDS(here::here("tests/testthat/testdata/test_meth.RDS"))
  test_conf <- readRDS(here::here("tests/testthat/testdata/test_conf.RDS"))
  expo_labels <- c("2,4-Dichlorophenol (2,4-DCP)", "Triclosan (TCS)")
  exposures <- colnames(dplyr::select(test_conf, DCP_24, TCS))
  confounders <- c("center", "active_smoking_T1", "mother_age", "parity", "mother_edu", "season_conception")


  # 1. no cell mix in the model
  file_name <- "result_input_no_cellmix"

  technical_confounders <- c("chip", "plate", "batch")
  expo_cov <- dplyr::select(test_conf,
                            id,
                            tidyselect::all_of(exposures),
                            tidyselect::all_of(confounders),
                            tidyselect::all_of(technical_confounders))

  result_input_no_cellmix <- RobustRegressions::SpecificLociMethylationRegressions(
    meth_data = test_meth,
    expo_cov = expo_cov,
    exposures = exposures,
    confounders = confounders,
    technical_confounders = technical_confounders,
    maxit = 400,
    ncores = 2, # the number of cores available to packages tests is 2, for performance reasons
    annotation_object = IlluminaHumanMethylation450kanno.ilmn12.hg19,
    expo_labels = expo_labels,
    path = "tests/testthat/testdata",
    file_name = file_name)

  result_output_no_cellmix <- readRDS(here::here("tests/testthat/testdata/result_output_no_cellmix.RDS"))

  testthat::expect_equal(result_input_no_cellmix, result_output_no_cellmix)


  # 2. Add cell mix in the model
  file_name <- "result_input_with_cellmix"

  technical_confounders <- c("chip", "plate", "batch", "cell_1", "cell_2", "cell_3", "cell_4", "cell_5", "cell_6")
  expo_cov <- dplyr::select(test_conf,
                            id,
                            tidyselect::all_of(exposures),
                            tidyselect::all_of(confounders),
                            tidyselect::all_of(technical_confounders))

  result_input_with_cellmix <- RobustRegressions::SpecificLociMethylationRegressions(
    meth_data = test_meth,
    expo_cov = expo_cov,
    exposures = exposures,
    confounders = confounders,
    technical_confounders = technical_confounders,
    maxit = 400,
    ncores = 2,
    annotation_object = IlluminaHumanMethylation450kanno.ilmn12.hg19,
    expo_labels = expo_labels,
    path = "tests/testthat/testdata",
    file_name = file_name)

  result_output_with_cellmix <- readRDS(here::here("tests/testthat/testdata/result_output_with_cellmix.RDS"))

  testthat::expect_equal(result_input_with_cellmix, result_output_with_cellmix)

})













